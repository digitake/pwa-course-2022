import '../css/Titlebar.css';

function Titlebar ({value}) {
  return (
    <div className="titlebar">
      {value}
    </div>
  )
}

export default Titlebar;