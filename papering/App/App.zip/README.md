# pwa-course-2022
Course for Progressive Web Apps 2022

------------------
Prerequisite: Exercise 06-01

If you don't see node_modules folder, run `npm install`
------------------

Exercise 07-01
1. Create branch class/07/ex01 and merge class/07/ex01 from class-origin
2. Study the code structure
3. Implement FriendList page
4. Commit with your student id in commit message
5. Push to you repo