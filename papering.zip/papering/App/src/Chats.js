import './css/Chats.css'

function Chats(){
    return (
        <div className='friends-page'>
            <div className='Chat-Top'> Chats  </div>
            <div>This is your chats list.</div>
            <div className='ProfilePic'> A  </div>
            <div className='list'>--- Username A ---</div>
            <div className='list'>--- Message ---</div>
            <div className='ProfilePic'> B  </div>
            <div className='list list-2'>--- Username B ---</div>
            <div className='list list-2'>--- Message ---</div>
            <div className='ProfilePic'> C  </div>
            <div className='list list-3'>--- Username C ---</div>
            <div className='list list-3'>--- Message ---</div>
            <div className='Button'>   </div>
        </div>
        
    )
}
export default Chats