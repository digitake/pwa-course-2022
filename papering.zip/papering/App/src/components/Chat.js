export function Chat () {
  return (
    <div className="chat">
    </div>
  )
}