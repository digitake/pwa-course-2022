import './css/Friends.css'

function Friends(){
    return (
        <div className='friends-page'>
            <div className='Friend'> Friends  </div>
            <div>This is your friends list.</div>
            <div>Friends 3</div>
            <div className='ProfilePic'> A  </div>
            <div className='list'>--- Username A ---</div>
            <div className='ProfilePic'> B  </div>
            <div className='list list-2'>--- Username B ---</div>
            <div className='ProfilePic'> C  </div>
            <div className='list list-3'>--- Username C ---</div>
            <div className='Button'>   </div>
        </div>
        
    )
}
export default Friends